Estas son imagenes de cassette y diskettes recuperadas en Atariada 2008
organizada por RetroGames.cl el 03-May-2008

Imagenes de Cassette
--------------------
cain1.cas : Ejemplo de carga con CAIN I (deshabilitar SIO PATCH en emulador)
cain2.cas : Ejemplo de carga con CAIN II (habilitar SIO PATCH para ver 2da animacion)
cain3.cas : Ejemplo de carga con CAIN III (a simple vista no veo la diferencia
    respecto a CAIN I, deshabilitar SIO PATCH en emulador)

Imagenes de disco
--------------------
Disco 2a.atr
Codigo fuente de diversas rutinas en ASM.  Incluye parte del cargador CAIN II

Disco 3a.atr
DIR : Utilidad para ver el contenido del disco sin entrar a DOS  (RUN "D:DIR")

TURBO : Desprotector de Cassettes Turbo Software

INJEKTOR : Desprotector de Cassettes Injektor de Prisma

DICTADOR.BAS : Desensamblador de la ROM del Atari.  Lo curioso es que opera
    con un sintetizador de voz.  Probablemente porque no tenia 
    disponibilidad de usar el televisor todo el tiempo.

COPYDISK : Copiador de discos (generico?)

DATABASE.BAS : Mi primer pituto comercial, lo hice para ayudar en la
    contabilidad de un tio.  Es muy precario pero salvo!

SENDER.BAS : Programa para enviar datos desde Atari a MSX por
    el  puerto de joystick

COMPRIME.BAS : Compresor

DESCOM.BAS : Descompresor

BINARY.BAS : Cargador binario, seguramente para despues aplicar el desensamblador

EXAMIN.BAS : Cargador binario, parce que solo para revisar los "chunks" de un
    archivo ejecutable
    
Disco 3b.atr
DESEN.DES : Desensamblador.  Pide una direccion y desensambla a partir de ahi.
    Tambien puede simular que el codigo se encuentra en otra direccion.
    Incluye un cargador binario (presionando solo ENTER en la direccion).
    Como otras utilidades, se puede escribir DIR en vez del nombre del archivo
    para ver cual carga.
    Incluye varias rutinas en assembler que no recuerdo para que eran.
    Parece que este mismo use para imprimir la ROM, recuerdo que imprimia
    a 3 columnas, pero el despliegue era distinto que el de pantalla
    
DESPRO : Restauraba el nombre de las variables de un programa basic al que
    le hubieran borrado los nombres con fines de proteccion.  No es
    de mi autoria

CAINJEK : Copiador de archivos binarios de disco (juegos) a cassettes con
    el sistema Injektor.  Fue lo primero que probamos en la Atariada 2008

Disco 4b.atr
Disco booteable con:

CAIN : Copiador CAIN (disco -> cassette) para programas binarios (juegos)

BASIC : Copiador CAIN con cargador especial para programas en BASIC

DESCAIN : Desprotector del cargador CAIN.  No recuerdo su proposito!

CASII : Copiador CAIN II (disco -> cassette)

CAINIII : Copiador CAIN III.  No recordaba su existencia, quizas fue
    un proyecto que nunca terminé

INJEKBAS : Copiador CAIN injektor para programas en BASIC

Disco 6a.atr
Disco corrupto, pero tiene algunas cosas rescatables

CDISKII : Probablemente CAIN II para disco, lamentablemente le faltan
    los archivos binarios :(  (CDISKII1.BIN).  Parece estar basado en otro
    copiador generico (copydisk?)

DISKII : Tengo que buscar las diferencias con CDISKII, se ven parecidos

FACT.BAS : Generador de facturas.  Probablemente para la electronica

TEST.BAS : Prueba de algo.. tiene pinta de que primer habia que cargar
    el codigo binario en 1536

ORDEN.BAS : Manejo de Ordenes de Trabajo de la Electronica

--
Franco Catrin L. 2008
http://www.tuxpan.com/fcatrin
